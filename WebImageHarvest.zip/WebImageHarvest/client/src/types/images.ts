import { Image } from "@shared/schema";

export interface ExtractResponse {
  url: string;
  images: Image[];
}
